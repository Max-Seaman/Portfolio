<body>
    <div id="sidebar">
        <a href="/" class="initials">MS</a>
        <a href="about-me">About Me</a>
        <a href="/#projects">My Projects</a>
        <a href="coding-examples">Coding Examples</a>
        <a href="scs-scheme">SCS Scheme</a>
        <a href="/#contactform" class="list--bordered">Contact Me</a>
        <div id="social-links">
            <a href="https://www.linkedin.com/in/max-seaman-915962375/" target="_blank"><i class="icon icon-linkedin"></i></a>
            <a href="https://github.com/Max-Seaman" target="_blank"><i class="icon icon-github"></i></a>
            <a href="https://discord.com/users/1387338523975090199" target="_blank" class="discord"><i class="icon icon-discord"></i></a>
        </div>
    </div>

    <div id="menu">
        <span></span>
        <span></span>
        <span></span>
    </div>