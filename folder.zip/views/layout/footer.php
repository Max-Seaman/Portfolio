<footer>
    <div class="hero__txt--up">
        <a href="#"><i class="icon icon-up"></i></a>
    </div>
    <p>&copy; Max Seaman | 2025</p>
</footer>